﻿﻿import React from 'react';
import { BarChart3, Briefcase, Users, Building2, FileText } from 'lucide-react';
import { NavBar } from './ui/tubelight-navbar';

const Navigation = () => {
  const navItems = [
    { name: 'Dashboard', url: '/dashboard', icon: BarChart3 },
    { name: 'Jobs', url: '/jobs', icon: Briefcase },
    { name: 'Candidates', url: '/candidates', icon: Users },
    { name: 'Assessments', url: '/assessments', icon: FileText }
  ];

  return (
    <>
      {/* Logo Header */}
      <div className="pt-16 pb-2 flex justify-center">
        <div className="flex items-center">
          {/* <Building2 className="h-8 w-8 text-primary" /> */}
          <span className="ml-2 text-xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            TalentFlow
          </span>
        </div>
      </div>
      
      {/* Tubelight Navigation */}
      <NavBar items={navItems} />
    </>
  );
};

export default Navigation;
